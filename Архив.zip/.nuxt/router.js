import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5a30ed84 = () => interopDefault(import('../pages/analytics.vue' /* webpackChunkName: "pages/analytics" */))
const _1f7a8a32 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _28bd87aa = () => interopDefault(import('../pages/print.vue' /* webpackChunkName: "pages/print" */))
const _ad2e23d6 = () => interopDefault(import('../pages/settings.vue' /* webpackChunkName: "pages/settings" */))
const _887d190e = () => interopDefault(import('../pages/storage.vue' /* webpackChunkName: "pages/storage" */))
const _269b17d0 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/analytics",
    component: _5a30ed84,
    name: "analytics"
  }, {
    path: "/login",
    component: _1f7a8a32,
    name: "login"
  }, {
    path: "/print",
    component: _28bd87aa,
    name: "print"
  }, {
    path: "/settings",
    component: _ad2e23d6,
    name: "settings"
  }, {
    path: "/storage",
    component: _887d190e,
    name: "storage"
  }, {
    path: "/",
    component: _269b17d0,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
